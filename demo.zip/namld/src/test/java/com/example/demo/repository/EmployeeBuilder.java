package com.example.demo.repository;

import com.example.demo.model.Dependent;
import com.example.demo.model.Employee;

public class EmployeeBuilder {

	private String name;
	private String[] depentNames = new String[] {};

	public static EmployeeBuilder aEmployee() {
		return new EmployeeBuilder();
	}

	public EmployeeBuilder withName(String name) {
		this.name = name;
		return this;
	}

	public EmployeeBuilder withDependents(String... depentNames) {
		this.depentNames = depentNames;
		return this;
	}

	public Employee build() {
		Employee e = new Employee();
		e.setName(name);
		
		for (int i = 0; i < depentNames.length; i++) {
			Dependent dependent = new Dependent();
			dependent.setName(depentNames[i]);
			dependent.setLinkedEmployee(e);
			e.getDependents().add(dependent);
		}
		return e;
	}

}
