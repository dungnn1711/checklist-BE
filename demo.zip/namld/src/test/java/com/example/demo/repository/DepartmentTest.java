package com.example.demo.repository;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.example.demo.model.Department;
import com.example.demo.model.DepartmentManagement;
import com.example.demo.model.Employee;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
class DepartmentTest {

	@Autowired
	private DepartmentRepository departmentRepo;
	
	@Autowired
	private EmployeeRepository employeeRepo;
	
	@Autowired
	private DepartmentManagementRepository departmentManagementRepo;

	@Test
	@Rollback(false)
	public void testCreate() {
		List<String> locations = Arrays.asList("VIT", "Handi");
		Employee manager = new Employee();
		manager.setName("Nguyen Khanh Binh");
		employeeRepo.save(manager);
		
		Department department = new Department();
		department.setName("SWC");
		department.setLocations(locations);
		department.setNumberOfEmployees(80);
		departmentRepo.save(department);
		
		DepartmentManagement departmentManagement = new DepartmentManagement();
		departmentManagement.setDepartment(department);
		departmentManagement.setManager(manager);
		
		department.getDepartmentManagements().add(departmentManagement);
		manager.getManagements().add(departmentManagement);
		departmentManagementRepo.save(departmentManagement);
	}
}
