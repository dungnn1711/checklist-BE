package com.example.demo.dto;

import java.time.OffsetDateTime;
import java.util.HashSet;
import java.util.Set;

import lombok.Data;

@Data
public class RequestDTO {
	private int id;
	private String status;
	private int employeeId;
	private String employeeName;
	private OffsetDateTime creationTime;

	private Set<RecordDTO> records = new HashSet<>();
}
