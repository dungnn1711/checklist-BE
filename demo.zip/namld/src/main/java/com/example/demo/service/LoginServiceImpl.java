package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dto.AccountDTO;
import com.example.demo.exception.ResourceNotfoundException;
import com.example.demo.model.Account;
import com.example.demo.repository.AccountRepository;

@Component
public class LoginServiceImpl implements LoginService {

	@Autowired
	AccountRepository repo;
	
	@Override
	public void login(AccountDTO account) throws ResourceNotfoundException {
		Optional<Account> entityAccount = repo.findByUserAndPassword(account.getUsername(), account.getPassword());
		if (!entityAccount.isPresent()) {
			throw new ResourceNotfoundException(account.getUsername() + " | " + account.getPassword());
		}
	}

}
