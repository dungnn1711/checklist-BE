package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.RequestCreationDTO;
import com.example.demo.dto.RequestDTO;
import com.example.demo.service.RequestService;

@Controller
@RequestMapping(value = "/work-requests")
public class RequestController {

	@Autowired
	private RequestService service;

	@GetMapping
	public ResponseEntity<?> get(
			@RequestParam Optional<Integer> employeeId,
			@RequestParam Optional<String> sort) {
		List<RequestDTO> requests = service.getAll(employeeId, sort);
		return ResponseEntity.ok(requests);
	}

	@GetMapping(value = "/{id}")
	public ResponseEntity<?> get(@PathVariable int id) {
		RequestDTO request = service.getById(id);
		return ResponseEntity.ok(request);
	}

	@PostMapping
	public ResponseEntity<?> create(@RequestBody RequestCreationDTO request) {
		service.create(request);
		return ResponseEntity.ok().build();
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<?> delete(@PathVariable int id) {
		service.delete(id);
		return ResponseEntity.ok().build();
	}

	@PostMapping(value = "/{id}/submit")
	public ResponseEntity<?> submit(@PathVariable int id) {
		service.submit(id);
		return ResponseEntity.ok().build();
	}

	@PostMapping(value = "/{id}/approve")
	public ResponseEntity<?> approve(@PathVariable int id) {
		service.approve(id);
		return ResponseEntity.ok().build();
	}

	@PostMapping(value = "/{id}/denine")
	public ResponseEntity<?> denine(@PathVariable int id) {
		service.denine(id);
		return ResponseEntity.ok().build();
	}
}
