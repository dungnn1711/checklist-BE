package com.example.demo.service;

import com.example.demo.model.Employee;

public interface EmployeeService {

	Iterable<Employee> getAll();

	Employee getById(int id);

	int create(Employee employee);

	Employee update(int id, Employee employee);

	void delete(int id);

}
