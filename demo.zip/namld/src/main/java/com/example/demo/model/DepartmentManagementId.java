package com.example.demo.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;

@Embeddable
public class DepartmentManagementId implements Serializable {
	private static final long serialVersionUID = -6025474864560998662L;

	private Integer departmentId;
	private Integer managerId;

	public DepartmentManagementId() {
	}

	public DepartmentManagementId(Integer departmentId, Integer managerId) {
		super();
		this.departmentId = departmentId;
		this.managerId = managerId;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((departmentId == null) ? 0 : departmentId.hashCode());
		result = prime * result + ((managerId == null) ? 0 : managerId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DepartmentManagementId other = (DepartmentManagementId) obj;
		return Objects.equals(getDepartmentId(), other.getDepartmentId())
				&& Objects.equals(getManagerId(), other.getManagerId());
	}
}
