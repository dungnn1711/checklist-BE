package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.AccountDTO;
import com.example.demo.mapper.AccountMapper;
import com.example.demo.model.Account;
import com.example.demo.repository.AccountRepository;

@Service
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	AccountRepository repo;
	
	@Override
	public int register(AccountDTO account) {
		Account entityAccount = AccountMapper.map(account);
		Account saved = repo.save(entityAccount);
		return saved.getId();
	}

}
