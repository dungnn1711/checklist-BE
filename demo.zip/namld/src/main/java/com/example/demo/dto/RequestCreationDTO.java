package com.example.demo.dto;

import java.util.List;

import lombok.Data;

@Data
public class RequestCreationDTO {
	private int employeeId;
	private List<RecordCreationDTO> records;
}
