package com.example.demo.service;

import com.example.demo.dto.AccountDTO;
import com.example.demo.exception.ResourceNotfoundException;

public interface LoginService {

	void login(AccountDTO account) throws ResourceNotfoundException;

}
