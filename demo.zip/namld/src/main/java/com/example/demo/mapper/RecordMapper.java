package com.example.demo.mapper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.demo.dto.RecordCreationDTO;
import com.example.demo.dto.RecordDTO;
import com.example.demo.model.Employee;
import com.example.demo.model.Record;

public class RecordMapper {

	public static Set<Record> map(List<RecordCreationDTO> dtoRecords, Employee owner, String status) {
		Set<Record> records = new HashSet<>();
		for (RecordCreationDTO record : dtoRecords) {
			Record recordEntity = new Record();
			recordEntity.setDescription(record.getDescription());
			recordEntity.setOwner(owner);
			recordEntity.setStatus(status);
			recordEntity.setStart(record.getStart());
			recordEntity.setEnd(record.getEnd());
			records.add(recordEntity);
		}
		return records;
	}

	public static RecordDTO map(Record record) {
		RecordDTO dto = new RecordDTO();
		dto.setDescription(record.getDescription());
		dto.setStart(record.getStart());
		dto.setEnd(record.getEnd());
		dto.setStatus(record.getStatus());
		return dto;
	}
}
