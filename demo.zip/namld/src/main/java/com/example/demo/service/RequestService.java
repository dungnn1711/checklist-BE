package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.dto.RequestCreationDTO;
import com.example.demo.dto.RequestDTO;

public interface RequestService {

	List<RequestDTO> getAll(Optional<Integer> filteredOwnerId, Optional<String> sort);
	RequestDTO getById(int id);
	void create(RequestCreationDTO request);
	void delete(int id);
	void submit(int id);
	void approve(int id);
	void denine(int id);
}
