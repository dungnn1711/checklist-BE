package com.example.demo.mapper;

import com.example.demo.dto.RecordDTO;
import com.example.demo.dto.RequestDTO;
import com.example.demo.model.Record;
import com.example.demo.model.Request;

public class RequestMapper {

	public static RequestDTO map(Request request) {
		RequestDTO requestDto = new RequestDTO();
		requestDto.setId(request.getId());
		requestDto.setEmployeeId(request.getOwner().getNumber());
		requestDto.setEmployeeName(request.getOwner().getName());
		requestDto.setStatus(request.getStatus());
		requestDto.setCreationTime(request.getCreationTime());

		for (Record record : request.getRecords()) {
			RecordDTO dto = RecordMapper.map(record);
			requestDto.getRecords().add(dto);
		}

		return requestDto;
	}

}
