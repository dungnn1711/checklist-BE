package com.example.demo.dto;

import lombok.Data;

@Data
public class AccountDTO {
	private String username;
	private String password;
}
