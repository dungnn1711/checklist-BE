package com.example.demo.model;

import static javax.persistence.GenerationType.AUTO;

import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "record")
public class Record {
	@Id
	@GeneratedValue(strategy = AUTO)
	private int id;

	@Column(name = "start_time")
	private OffsetDateTime start;

	@Column(name = "end_time")
	private OffsetDateTime end;
	
	@Column
	private String description;
	
	// APPROVED, DRAFT
	@Column
	private String status;

	@ManyToOne
	private Employee owner;
}
