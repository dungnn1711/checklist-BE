package com.example.demo.mapper;

import com.example.demo.dto.AccountDTO;
import com.example.demo.model.Account;

public class AccountMapper {

	public static Account map(AccountDTO account) {
		Account entityAccount = new Account();
		entityAccount.setPassword(account.getPassword());
		entityAccount.setUser(account.getUsername());
		return entityAccount;
	}

}
