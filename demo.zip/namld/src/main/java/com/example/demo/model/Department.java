package com.example.demo.model;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "department")
public class Department {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private int number;

	@Column
	private String name;
	
	@Column
	private int numberOfEmployees;
	
	@ElementCollection
	private List<String> locations;
	
    @OneToMany(mappedBy = "department")
    private Set<DepartmentManagement> departmentManagements = new HashSet<>();
}
