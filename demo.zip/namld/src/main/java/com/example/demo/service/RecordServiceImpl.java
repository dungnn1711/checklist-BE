package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Record;
import com.example.demo.repository.RecordRepository;

@Service
public class RecordServiceImpl implements RecordService {

	@Autowired
	RecordRepository repo;
	
	@Override
	public List<Record> findAll() {
		return (List<Record>) repo.findAll();
	}

}
