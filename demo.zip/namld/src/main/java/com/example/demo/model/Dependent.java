package com.example.demo.model;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "dependent")
public class Dependent {
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private int id;

	@Column
	private String name;

	@Column
	private String sex;

	@Column(name = "birth_date")
	private Date birthDate;

	@Column
	private String relationship;

	@ManyToOne(optional = false)
	private Employee linkedEmployee;

}
