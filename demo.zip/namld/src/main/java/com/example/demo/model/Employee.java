package com.example.demo.model;

import static javax.persistence.CascadeType.ALL;
import static javax.persistence.GenerationType.AUTO;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = AUTO)
	private int number;
	
	@Column
	private int ssn;

	@Column
	private Date birthDate;
	
	@Column
	private String sex;
	
	@Column
	private String address;
	
	@Column
	private int salary;

	@Column
	private String name;
	
	@Column
	private String phone;

	@OneToMany(mappedBy = "manager")
	private Set<DepartmentManagement> managements = new HashSet<>();

	@OneToMany(mappedBy = "linkedEmployee", cascade = ALL)
	private Set<Dependent> dependents = new HashSet<>();

	@OneToMany(mappedBy = "owner", cascade = ALL)
	private Set<Record> workRecords = new HashSet<>();
	
	@OneToMany(mappedBy = "owner", cascade = ALL)
	private Set<Request> workRecordRequests = new HashSet<>();
	
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "account_id", referencedColumnName = "id")
	private Account account;
}
