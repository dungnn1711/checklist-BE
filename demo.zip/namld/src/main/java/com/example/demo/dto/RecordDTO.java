package com.example.demo.dto;

import java.time.OffsetDateTime;

import lombok.Data;

@Data
public class RecordDTO {
	private String description;
	private String status;
	private OffsetDateTime start;
	private OffsetDateTime end;
}
