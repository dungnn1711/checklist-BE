package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.DepartmentManagement;
import com.example.demo.model.DepartmentManagementId;

public interface DepartmentManagementRepository extends CrudRepository<DepartmentManagement, DepartmentManagementId> {

}
