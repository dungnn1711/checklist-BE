package com.example.demo.dto;

import java.time.OffsetDateTime;

import lombok.Data;

@Data
public class RecordCreationDTO {
	private OffsetDateTime start;
	private OffsetDateTime end;
	private String description;
	private String status;
}
