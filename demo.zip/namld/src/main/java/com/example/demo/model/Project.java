package com.example.demo.model;

import static javax.persistence.FetchType.LAZY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Project {
	@Id
	private int number;

	@ManyToOne(fetch = LAZY)
	private Department department;

	@Column
	private String name;

	@Column
	private String location;
}
