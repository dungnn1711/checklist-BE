package com.example.demo.dto;

import lombok.Data;

@Data
public class AccountCreationDTO {
	private int employeeId;
	private int roleId;
	private String user;
	private String password;
}
