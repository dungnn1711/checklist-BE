package com.example.demo.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

@Controller
@RequestMapping(value = "/employees")
public class EmployeeController {
	
	@Autowired
	EmployeeRepository employeeRepo;
	
	@Autowired
	EmployeeService service;
	
	@PostConstruct
	void init() {
		List<Employee> employees = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			Employee emp = new Employee(); 
			emp.setName("Employee " + String.valueOf(i));
			employees.add(emp);
		}
		employeeRepo.saveAll(employees);
	}

	@GetMapping
	public ResponseEntity<?> getAll() {
		return ResponseEntity.ok(service.getAll());
	}

	@GetMapping(value = "{id}")
	public ResponseEntity<Employee> get(@PathVariable int id) {
		Employee employee = service.getById(id);
		return ResponseEntity.ok(employee);
	}

	@PostMapping
	public ResponseEntity<?> create(@RequestBody Employee employee) throws URISyntaxException {
		int id = service.create(employee);
		return ResponseEntity.created(new URI("employee/" + String.valueOf(id))).build();
	}

	@PutMapping(value = "{id}")
	public ResponseEntity<?> put(@PathVariable int id, @RequestBody Employee employee) {
		Employee updatedEmployee = service.update(id, employee);
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping(value = "{id}")
	public ResponseEntity<?> delete(@PathVariable int id) {
		service.delete(id);
		return ResponseEntity.ok().build();
	}
}
