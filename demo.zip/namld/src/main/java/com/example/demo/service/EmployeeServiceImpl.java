package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.ResourceNotfoundException;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepo;
	
	@Override
	public Iterable<Employee> getAll() {
		return employeeRepo.findAll();
	}

	@Override
	public Employee getById(int id) {
		Optional<Employee> employee = employeeRepo.findById(id);
		if (!employee.isPresent()) {
			throw new ResourceNotfoundException("Employee not exists, id = " + String.valueOf(id));
		}
		return employee.get();
	}

	@Override
	public int create(Employee employee) {
		Optional<Employee> emp = employeeRepo.findById(employee.getNumber());
		if (emp.isPresent()) {
			throw new BadRequestException("Employee have existed, id = " + String.valueOf(employee.getNumber()));
		} else {
			Employee savedEmployee = employeeRepo.save(employee);
			return savedEmployee.getNumber();
		}
	}

	@Override
	public Employee update(int id, Employee employee) {
		Optional<Employee> emp = employeeRepo.findById(id);
		if (!emp.isPresent()) {
			throw new ResourceNotfoundException("Employee not existed, id = " + String.valueOf(id));
		} else {
			employee.setNumber(id);
			return employeeRepo.save(employee);
		}
	}

	@Override
	public void delete(int id) {
		Optional<Employee> emp = employeeRepo.findById(id);
		if (!emp.isPresent()) {
			throw new BadRequestException("Employee not existed, id = " + String.valueOf(id));
		} else {
			employeeRepo.deleteById(id);
		}
	}

}
