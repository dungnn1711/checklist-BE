package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class ProjectEmployee {
	@EmbeddedId
	private ProjectEmployeeId id = new ProjectEmployeeId();
	
	@MapsId(value = "projectId")
	@ManyToOne
	private Project project;
	
	@MapsId(value = "employeeId")
	@ManyToOne
	private Employee employee;
	
	@Column
	private int hours;
}
