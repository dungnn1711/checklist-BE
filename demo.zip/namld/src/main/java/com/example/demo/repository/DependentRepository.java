package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Dependent;

public interface DependentRepository extends CrudRepository<Dependent, Integer> {

}
