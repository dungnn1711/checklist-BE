package com.example.demo.exception;

public class BadRequestException extends RuntimeException {
	
	private static final long serialVersionUID = -5382112678734404268L;

	public BadRequestException() {
		super();
	}

	public BadRequestException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public BadRequestException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public BadRequestException(String arg0) {
		super(arg0);
	}

	public BadRequestException(Throwable arg0) {
		super(arg0);
	}

}
