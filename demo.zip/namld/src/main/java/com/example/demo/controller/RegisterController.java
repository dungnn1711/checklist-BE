package com.example.demo.controller;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.AccountDTO;
import com.example.demo.service.RegisterService;

@RestController
@RequestMapping(value = "/register")
public class RegisterController {

	@Autowired
	RegisterService service;
	
	@PostMapping
	public ResponseEntity<?> register(@RequestBody AccountDTO account) throws URISyntaxException {
		int id = service.register(account);
		return ResponseEntity.created(new URI("/user/" + String.valueOf(id))).build();
	}
}
