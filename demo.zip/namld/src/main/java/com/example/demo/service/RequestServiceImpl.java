package com.example.demo.service;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.dto.RequestCreationDTO;
import com.example.demo.dto.RequestDTO;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.ResourceNotfoundException;
import com.example.demo.mapper.RecordMapper;
import com.example.demo.mapper.RequestMapper;
import com.example.demo.model.Employee;
import com.example.demo.model.Record;
import com.example.demo.model.Request;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.RecordRepository;
import com.example.demo.repository.RequestRepository;

@Service
public class RequestServiceImpl implements RequestService {

	private static final String DEFAULT_SORT_FIELD = "id";
	private static final String SUBMIT = "SUBMITED";
	private static final String DRAFT = "DRAFT";
	private static final String APPROVED = "APPROVED";
	private static final String DENINE = "DENINE";

	@Autowired
	RequestRepository repo;

	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	RecordRepository recordRepo;

	@Override
	public List<RequestDTO> getAll(Optional<Integer> filteredOwnerId, Optional<String> sort) {
		List<RequestDTO> requests = new ArrayList<>();
		Iterable<Request> savedRequests = null;
		
		String sortField = DEFAULT_SORT_FIELD;
		if (!sort.isPresent()) {
			sortField = DEFAULT_SORT_FIELD;
		} else {
			sortField = sort.get();
		}
		
		Sort sortStrategy = Sort.by(Sort.Direction.ASC, sortField);
		if (filteredOwnerId.isPresent()) {
			savedRequests = repo.findByOwner_Number(filteredOwnerId.get(), sortStrategy);
		} else {
			savedRequests = repo.findAll(sortStrategy);
		}
		
		for (Request request : savedRequests) {
			RequestDTO requestDto = RequestMapper.map(request);
			requests.add(requestDto);
		}
		return requests;
	}

	@Override
	public RequestDTO getById(int id) {
		Optional<Request> request = repo.findById(id);
		if (!request.isPresent()) {
			throw new ResourceNotfoundException("Request id: " + String.valueOf(id));
		}
		return RequestMapper.map(request.get());
	}

	@Override
	public void create(RequestCreationDTO requestDto) {
		if (!empRepo.existsById(requestDto.getEmployeeId())) {
			throw new ResourceNotfoundException("Employee not exists, id = " + String.valueOf(requestDto.getEmployeeId()));
		}
		
		Employee owner = empRepo.findById(requestDto.getEmployeeId()).get();
		Set<Record> records = RecordMapper.map(requestDto.getRecords(), owner, DRAFT);

		Request requestEntity = new Request();
		requestEntity.setOwner(owner);
		requestEntity.setStatus(DRAFT);
		requestEntity.setCreationTime(OffsetDateTime.now());
		
		Iterable<Record> savedRecords = recordRepo.saveAll(records);
		for (Record record : savedRecords) {
			requestEntity.getRecords().add(record);
		}
		
		repo.save(requestEntity);
	}

	@Override
	public void delete(int id) {
		Request request = findRequest(id);
		if (!request.getStatus().equals(DRAFT)) {
			throw new BadRequestException("Request is not draft, id = " + String.valueOf(id));
		}
		repo.deleteById(id);
	}

	@Override
	public void submit(int id) {
		setStatus(id, SUBMIT);
	}

	@Override
	public void approve(int id) {
		setStatus(id, APPROVED);
	}

	private void setStatus(int id, String status) {
		Request request = findRequest(id);
		request.setStatus(status);
		for (Record record : request.getRecords()) {
			record.setStatus(status);
		}
		
		Set<Record> originalRecords = request.getRecords();
		Iterable<Record> records = recordRepo.saveAll(request.getRecords());
		originalRecords.clear();
		for (Record record : records) {
			originalRecords.add(record);
		}
		repo.save(request);
	}

	private Request findRequest(int id) {
		Optional<Request> requestOpt = repo.findById(id);
		if (!requestOpt.isPresent()) {
			throw new ResourceNotfoundException("Request not exists, id = " + String.valueOf(id));
		}
		Request request = requestOpt.get();
		return request;
	}

	@Override
	public void denine(int id) {
		setStatus(id, DENINE);
	}

}
