package com.example.demo.service;

import com.example.demo.model.Account;

public interface AccountService {

	Iterable<Account> getAll();
	Account get(int id);

}
