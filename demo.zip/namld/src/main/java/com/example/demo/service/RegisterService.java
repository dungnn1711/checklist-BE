package com.example.demo.service;

import com.example.demo.dto.AccountDTO;

public interface RegisterService {

	int register(AccountDTO account);

}
