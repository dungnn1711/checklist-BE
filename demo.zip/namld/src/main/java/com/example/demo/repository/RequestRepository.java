package com.example.demo.repository;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Request;

public interface RequestRepository extends JpaRepository<Request, Integer> {
	Iterable<Request> findByOwner_Number(int ownerNumber, Sort sort);
}
