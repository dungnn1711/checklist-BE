package com.tsdv.demo.controller;

import com.tsdv.demo.jwt.JwtTokenProvider;
import com.tsdv.demo.model.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AuthenticationController {

  @Autowired
  AuthenticationManager authenticationManager;

  @Autowired
  JwtTokenProvider jwtTokenProvider;

  @RequestMapping(value = "/api/login", method = RequestMethod.POST)
  public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
    
    String jwt = "";

    try {
   // valid username and password.
      Authentication authentication = authenticationManager.authenticate(
              new UsernamePasswordAuthenticationToken(
                      loginRequest.getUsername(),
                      loginRequest.getPassword()
              )
      );

      // save authentication into Security context
      SecurityContextHolder.getContext().setAuthentication(authentication);
      
      jwt = jwtTokenProvider.generateToken((UserDetails) authentication.getPrincipal());
    } catch (Exception e) {
      e.printStackTrace();
    }

    // return jwt to user
    return new ResponseEntity<>(jwt, HttpStatus.OK);

  }

}
