package com.tsdv.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {
  
  @GetMapping(value = "/")
  public String home() {
    return "index";
  }
  
  @GetMapping(value = "/admin")
  public String admin() {
    return "admin";
  }
  
  @GetMapping(value = "/leader")
  public String leader() {
    return "leader";
  }
  
  @GetMapping(value = "/member")
  public String member() {
    return "member";
  }

}
