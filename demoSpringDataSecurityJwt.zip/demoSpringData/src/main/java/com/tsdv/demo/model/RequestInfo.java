package com.tsdv.demo.model;

import com.tsdv.demo.entity.RequestStatus;
import java.sql.Date;
import java.util.UUID;

public class RequestInfo {
  
private UUID id;
  
  private Date createdTime;
  
  private String message;
  
  private RequestStatus status;
  
  private int requesterId;
  
  public RequestInfo() {
  }
  
  public RequestInfo(UUID id, Date createdTime, String message, RequestStatus status, int requesterId) {
    this.id = id;
    this.createdTime = createdTime;
    this.message = message;
    this.status = status;
    this.requesterId = requesterId;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public Date getCreatedTime() {
    return createdTime;
  }

  public void setCreatedTime(Date createdTime) {
    this.createdTime = createdTime;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public RequestStatus getStatus() {
    return status;
  }

  public void setStatus(RequestStatus status) {
    this.status = status;
  }

  public int getRequesterId() {
    return requesterId;
  }

  public void setRequesterId(int requesterId) {
    this.requesterId = requesterId;
  }
  
  

}
