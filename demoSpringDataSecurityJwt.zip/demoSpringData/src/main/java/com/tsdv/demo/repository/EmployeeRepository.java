package com.tsdv.demo.repository;

import com.tsdv.demo.entity.Employee;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
  
  // Query creation
  List<Employee> findAllByName(String name);
  
  // JPQL
  @Query("SELECT e FROM Employee e WHERE name = :name") // Capitalize "Employee" follow class name
  Optional<Employee> findByNameJPQL(@Param("name") String name);
  
  // Native SQL
  @Query(value = "SELECT * FROM employee WHERE name = :name", nativeQuery = true)
  Optional<Employee> findByNameNative(@Param("name") String name);
  
  @Query(value = "SELECT id FROM employee WHERE super_id = :id", nativeQuery = true)
  List<Integer> getMembers(@Param("id") int id);

}