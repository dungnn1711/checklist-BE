package com.tsdv.demo.service;

import com.tsdv.demo.model.RequestInfo;
import java.util.List;
import java.util.UUID;

public interface RequestService {
  
  public List<RequestInfo> getAllRequestsOfEmpl(int emplId);
  
  public boolean add(RequestInfo request);
  
  public boolean update(UUID id, RequestInfo request);
  
  public boolean delete(UUID id);
  
  public boolean checkExisted(UUID id);

}
