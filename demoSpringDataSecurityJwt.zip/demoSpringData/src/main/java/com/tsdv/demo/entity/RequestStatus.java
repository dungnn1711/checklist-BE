package com.tsdv.demo.entity;

public enum RequestStatus {
  DRAFT,
  SUMMIT,
  APPROVE,
  DENINE
}
