package com.tsdv.demo.dao;

import com.tsdv.demo.entity.Employee;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
public class JdbcEmployeeDao {

  @Autowired
  NamedParameterJdbcTemplate jdbcTemplate;

  public List<Employee> getAll() {
    String sql = "SELECT * FROM employee;";
    try {
      return jdbcTemplate.query(sql, new MapSqlParameterSource(), new RowMapper<Employee>() {

        @Override
        public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
          return new Employee(
              rs.getInt("id"),
              rs.getString("name"),
              rs.getDate("dob"),
              rs.getString("phone"),
              rs.getString("role"),
              rs.getString("password")
              );
        }

      });
    } catch (Exception e) {
      e.printStackTrace();
      return new ArrayList<Employee>();
    }
  }

  public Employee getById(int id) {
    String sql = "SELECT * FROM employee WHERE id=:id";
    try {
      return jdbcTemplate.queryForObject(sql, new MapSqlParameterSource("id", id), BeanPropertyRowMapper.newInstance(Employee.class));
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  public boolean checkExisted(int id) {
    String sql = "SELECT count(0) FROM employee WHERE id=:id";
    try {
      int numOfEmployee = jdbcTemplate.queryForObject(sql,  new MapSqlParameterSource("id", id), Integer.class);
      return numOfEmployee > 0;
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
    
  }

  public boolean add(Employee employee) {
    try {
      String sql = "INSERT INTO employee(id, name, dob, phone, role, password) VALUES (:id, :name, :dob, :phone, :role, :password)";
      SqlParameterSource paramMap = new MapSqlParameterSource("id", employee.getId())
          .addValue("name", employee.getName())
          .addValue("dob", employee.getDob())
          .addValue("phone", employee.getPhone())
          .addValue("role", employee.getRole())
          .addValue("password", employee.getPassword());
      return  jdbcTemplate.update(sql, paramMap) > 0;
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
  }

  public boolean update(int id, Employee employee) {
    try {
      String sql = "UPDATE employee SET name=:name, dob=:dob, phone=:phone, role=:role, password=:password WHERE id=:id";
      SqlParameterSource paramMap = new MapSqlParameterSource("id", id)
          .addValue("name", employee.getName())
          .addValue("dob", employee.getDob())
          .addValue("phone", employee.getPhone())
          .addValue("role", employee.getRole())
          .addValue("password", employee.getPassword());
      return  jdbcTemplate.update(sql, paramMap) > 0;
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
  }

  public boolean remove(int id) {
    try {
      String sql = "DELETE FROM employee WHERE id=:id";
      SqlParameterSource paramMap = new MapSqlParameterSource("id", id);
      return  jdbcTemplate.update(sql, paramMap) > 0;
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
  }

}
