package com.tsdv.demo.service;

import com.tsdv.demo.entity.Employee;
import com.tsdv.demo.repository.EmployeeRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(value = "spring.data", havingValue = "jpa")
public class JpaEmployeeServiceImpl implements EmployeeService {

  @Autowired
  private EmployeeRepository employeeRepository;
  
  @Override
  public List<Employee> getAll() {
    return employeeRepository.findAll();
  }

  @Override
  public Employee getById(int id) {
    try {
      return employeeRepository.findById(id).get();
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  @Override
  public boolean checkExisted(int id) {
    return employeeRepository.existsById(id);
  }

  @Override
  public boolean add(Employee employee) {
    try {
      employeeRepository.save(employee);
      return true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;

  }

  @Override
  public boolean update(int id, Employee employee) {
    try {
      if (this.checkExisted(id)) {
        employeeRepository.save(employee);
        return true;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean remove(int id) {
    try {
      if (this.checkExisted(id)) {
        employeeRepository.deleteById(id);
        return true;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public List<Integer> getMembers(int id) {
    return employeeRepository.getMembers(id);
  }

}
