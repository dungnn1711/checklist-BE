package com.tsdv.demo.service;

import com.tsdv.demo.dao.JdbcEmployeeDao;
import com.tsdv.demo.entity.Employee;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(value = "spring.data", havingValue = "jdbc")
public class JdbcEmployeeServiceImpl implements EmployeeService {
  
  @PostConstruct
  private void init() {
    System.out.println("JdbcEmployeeServiceImpl created!");
  }

  @Autowired
  private JdbcEmployeeDao jdbcEmployeeDao;

  @Override
  public List<Employee> getAll() {
    return jdbcEmployeeDao.getAll();
  }

  @Override
  public Employee getById(int id) {
    return jdbcEmployeeDao.getById(id);
  }

  @Override
  public boolean checkExisted(int id) {
    return jdbcEmployeeDao.checkExisted(id);
  }

  @Override
  public boolean add(Employee employee) {
    return jdbcEmployeeDao.add(employee);
  }

  @Override
  public boolean update(int id, Employee employee) {
    return jdbcEmployeeDao.update(id, employee);
  }

  @Override
  public boolean remove(int id) {
    return jdbcEmployeeDao.remove(id);
  }

  @Override
  public List<Integer> getMembers(int id) {
    // TODO Auto-generated method stub
    return null;
  }

}
