package com.tsdv.demo.repository;

import com.tsdv.demo.entity.Request;
import java.util.UUID;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RequestRepository extends JpaRepository<Request, UUID>{

  @Query(value = "DELETE FROM request WHERE id=:id AND status=0", nativeQuery = true)
  @Modifying
  @Transactional
  void delete(@Param("id") UUID id);
}
