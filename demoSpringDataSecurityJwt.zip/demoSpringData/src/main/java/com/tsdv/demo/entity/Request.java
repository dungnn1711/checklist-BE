package com.tsdv.demo.entity;

import com.tsdv.demo.model.RequestInfo;
import java.sql.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "request")
public class Request {

  @Id
  @Column(name = "id")
  private UUID id;
  
  @Column(name = "created_time")
  private Date createdTime;
  
  @Column(name = "message")
  private String message;
  
  @Column(name = "status")
  private RequestStatus status;
  
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "requester_id")
  private Employee employee;
  

  public Request() {
    // TODO Auto-generated constructor stub
  }
  
  public Request(UUID id, Date createdTime, int requesterId, String message, RequestStatus status) {
    this.id = id;
    this.createdTime = createdTime;
    this.message = message;
    this.status = status;
  }
  
  public Request(UUID id, Date createdTime, int requesterId, String message, RequestStatus status, Employee employee) {
    this.id = id;
    this.createdTime = createdTime;
    this.message = message;
    this.status = status;
    this.employee = employee;
  }


  public UUID getId() {
    return id;
  }


  public void setId(UUID id) {
    this.id = id;
  }


  public Date getCreatedTime() {

    return createdTime;
  }

  public void setCreatedTime(Date createdTime) {
    this.createdTime = createdTime;
  }


  public RequestStatus getStatus() {
    return status;
  }

  public void setStatus(RequestStatus status) {
    this.status = status;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public Employee getEmployee() {
    return employee;
  }

  public void setEmployee(Employee employee) {
    this.employee = employee;
  }
  
  public RequestInfo toRequestInfo() {
    return new RequestInfo(this.id, this.createdTime, this.message, this.status, employee.getId());
  }
  


}
