package com.tsdv.demo.service;

import com.tsdv.demo.entity.Employee;
import com.tsdv.demo.entity.Request;
import com.tsdv.demo.model.RequestInfo;
import com.tsdv.demo.repository.RequestRepository;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RequestServiceImpl implements RequestService{
  
  @Autowired
  EmployeeService employeeService;
  
  @Autowired
  RequestRepository requestRepository;

  @Override
  public List<RequestInfo> getAllRequestsOfEmpl(int emplId) {
    List<RequestInfo> requestInfos = new ArrayList<>();
    List<Integer> memberIds = employeeService.getMembers(emplId);
    requestInfos.addAll(getRequestOfEmpl(emplId));
    for (Integer memberId : memberIds) {
      requestInfos.addAll(getRequestOfEmpl(memberId));
    }
    return requestInfos;
  }
  
  private List<RequestInfo> getRequestOfEmpl(int emplId) {
    Employee employee = employeeService.getById(emplId);
    if(employee != null) {
      List<Request> requests =  employee.getRequests();
      return requests.stream().map(request -> request.toRequestInfo()).collect(Collectors.toList());
    }
    return new ArrayList<>();
  }

  @Override
  public boolean add(RequestInfo requestInfo) {
    try {
      int requesterId = requestInfo.getRequesterId();
      Employee employee = employeeService.getById(requesterId);
      Request request = new Request(UUID.randomUUID(), new Date(System.currentTimeMillis()),
          requesterId, requestInfo.getMessage(), requestInfo.getStatus(), employee);
      requestRepository.save(request);
      return true;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean update(UUID id, RequestInfo requestInfo) {
    try {
      if (this.checkExisted(id)) {
        int requesterId = requestInfo.getRequesterId();
        Employee employee = employeeService.getById(requesterId);
        Request request = new Request(id, requestInfo.getCreatedTime(),
            requesterId, requestInfo.getMessage(), requestInfo.getStatus(), employee);
        requestRepository.save(request);
        return true;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean delete(UUID id) {
    try {
      requestRepository.delete(id);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean checkExisted(UUID id) {
    return requestRepository.existsById(id);
  }

}
