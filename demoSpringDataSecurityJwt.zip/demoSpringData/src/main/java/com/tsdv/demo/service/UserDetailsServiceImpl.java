package com.tsdv.demo.service;

import com.tsdv.demo.entity.Employee;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

  @Autowired
  EmployeeService employeeService;

  @Override
  public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
    Employee employee = employeeService.getById(Integer.parseInt(loginId));
    
    List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
    grantList.add(new SimpleGrantedAuthority(employee.getRole()));
    return (UserDetails) new User(loginId, employee.getPassword(), grantList);
  }
}
