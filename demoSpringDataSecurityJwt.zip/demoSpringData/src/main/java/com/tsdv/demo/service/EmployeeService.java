package com.tsdv.demo.service;

import com.tsdv.demo.entity.Employee;
import java.util.List;

public interface EmployeeService {
  
  /**
   * Get all employees.
   * @return list of employee
   */
  public List<Employee> getAll();
  
  /**
   * Get employee by id.
   * @param id employee id
   * @return employee
   */
  public Employee getById(int id);
  
  /**
   * Check employee is existed or not.
   * @param id employee id
   * @return true is existed and vice versa
   */
  public boolean checkExisted(int id);
  
  /**
   * Add new employee to database.
   * @param employee
   * @return adding success or not
   */
  public boolean add(Employee employee);
  
  /**
   * Update employee
   * @param id id of employee need to update
   * @param employee new value
   * @return updating success or not
   */
  public boolean update(int id, Employee employee);
  
  /**
   * Remove employee from database
   * @param id employee id
   * @return removing success or not
   */
  public boolean remove(int id);
  
  
  /**
   * get list id of members
   * @param id leader id
   * @return
   */
  public List<Integer> getMembers(int id);

}
