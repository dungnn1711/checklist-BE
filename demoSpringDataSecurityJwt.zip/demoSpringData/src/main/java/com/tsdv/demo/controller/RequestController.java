package com.tsdv.demo.controller;

import com.tsdv.demo.model.RequestInfo;
import com.tsdv.demo.service.RequestService;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/requests")
public class RequestController {

  @Autowired
  private RequestService requestService;
  
  @PostMapping
  public ResponseEntity<String> add(@RequestBody RequestInfo requestInfo) {
    requestService.add(requestInfo);
    return new ResponseEntity<>("created!", HttpStatus.OK);
  }

  @DeleteMapping(value = "/{id}")
  public ResponseEntity<String> delete(@PathVariable UUID id) {
    if(requestService.delete(id)) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    return new ResponseEntity<>(HttpStatus.METHOD_NOT_ALLOWED);
  }

  @PatchMapping(value = "/{id}")
  public ResponseEntity<String> update(@PathVariable UUID id, @RequestBody RequestInfo requestInfo) {
    
    if(requestService.update(id, requestInfo)) {
      return new ResponseEntity<>("success", HttpStatus.OK);
    }
    return new ResponseEntity<>("fail", HttpStatus.NOT_FOUND);
  }



}
