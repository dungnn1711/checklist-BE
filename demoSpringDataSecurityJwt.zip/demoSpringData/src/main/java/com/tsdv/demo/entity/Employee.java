package com.tsdv.demo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {
  @Id
  @Column(name = "id")
  private int id;
  
  @Column(name = "name")
  private String name;
  
  @Column(name = "dob")
  private Date dob;
  
  @Column(name = "phone")
  private String phone;
  
  @Column(name = "role")
  private String role;
  
  @Column(name = "password")
  private String password;
  
  @OneToMany(fetch = FetchType.LAZY, mappedBy = "employee")
  @JsonIgnore
  private List<Request> requests = new ArrayList<>();


  public Employee() {}

  public Employee(int id, String name, Date dob, String phoneNo, String role, String password) {

    this.id = id;
    this.name = name;
    this.dob = dob;
    this.phone = phoneNo;
    this.role = role;
    this.password = password;

  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Date getDob() {
    return dob;
  }

  public void setDob(Date dob) {
    this.dob = dob;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getRole() {
    return role;
  }

  public void setRole(String role) {
    this.role = role;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public List<Request> getRequests() {
    return requests;
  }

  public void setRequests(List<Request> requests) {
    this.requests = requests;
  }
}
